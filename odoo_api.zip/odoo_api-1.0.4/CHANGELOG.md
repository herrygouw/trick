## [1.0.4] - Dependency Version Upgrade

- Updated http to 0.12.0+2
- Updated uuid to 2.0.2

## [1.0.3] - Bug fixes and improvements

- Authentication failed exception handled
- Handling session with Response
- Minor improvements and fixes

## [1.0.2] - First Release

- Minor improvements