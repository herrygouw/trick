{
    "name": "Domain to SQL",
    "author": "Ngasturi",
    "version": "1.0.0",
    "category": "",
    "website": 'https://ngasturi.id',
    "summary": "",
    "description": """
            
        """,
    "depends": [
        "base", 
    ],
    "data": [
    ],
    "license": 'LGPL-3', 
    "installable": True 
}
