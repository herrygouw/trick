# -*- coding: utf-8 -*-
{
    'name' : 'Show Chatter on Modal',
    'version' : '14.0.1.0.0',
    'author' : 'Ngasturi',
    'category': '',
    'website': 'https://en.ngasturi.id',    
    'depends' : ['mail'],
    'data': [
        'views/view.xml',
    ],
    'demo': [
    ],
    'qweb': [

    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
