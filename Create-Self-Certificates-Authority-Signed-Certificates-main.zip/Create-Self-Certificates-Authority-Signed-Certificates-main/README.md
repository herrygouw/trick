# Create-Self-Certificates-Authority-Signed-Certificates
Scripts to Configure Self CA and Sign Certs.

This repository contains two scripts (createCA.sh and createCert.sh)

- createCA.sh " This script is used to create the initial CA certificate. Once you create the CA certificate, import the certificate into your device and keep the Certificate and Key Safe somewhere safe on you hard drive, computer, or cloud. Here is the command to be executed :

sh createCA.sh 

- createCert.sh : This script is used to generate certificates for your domains in the future. And the command to be used is the one specified below :

createCert.sh

