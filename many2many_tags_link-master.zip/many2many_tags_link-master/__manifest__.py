# -*- coding: utf-8 -*-
{
    'name' : 'Many2many Tag Link',
    'version' : '12.0.1.0.0',
    'author' : 'Ngasturi',
    'summary': 'Many2many Tag Widget With Link',
    'description': '',
    'category': '',
    'website': 'https://github.com/znry27/many2many_tags_link',    
    'depends' : ['web'],
    'data': [
        'views/view.xml',
    ],
    'demo': [
    ],
    'qweb': [
        "static/src/xml/template.xml",
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
