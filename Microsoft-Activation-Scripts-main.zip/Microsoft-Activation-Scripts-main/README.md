# Microsoft-Activation-Scripts
A collection of scripts for activating Microsoft products using HWID / KMS38 / Online KMS activation methods with a focus on open-source code, less antivirus detection and user-friendliness.

Note:
Explanation and proposed fix for Office 2019 Get genuine banner:
https://github.com/massgravel/Microsoft-Activation-Scripts/issues/20

----------------------------------------------------------------------------------------------
Activation Type       Supported Product             Activation Period
----------------------------------------------------------------------------------------------

Digital License    -  Windows 10                 -  Permanent
KMS38              -  Windows 10 / Server        -  Until the year 2038
Online KMS         -  Windows / Server / Office  -  For 180 Days, renewal task needs to be 
                                                    created for lifetime auto activation.

----------------------------------------------------------------------------------------------

* For more details, use the ReadMe.txt included in the respective activation folders.

# What are you going to get ?

Digital License (HWID) Activation
KMS38 Activation
KMS38_Protection
Online KMS Activation
Activation Methods info and faqs
$OEM$ Folders (Windows Pre-Activation)
Big Blocks of text in the script
Download Genuine Installation Media
