#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      kingston
#
# Created:     20/02/2017
# Copyright:   (c) kingston 2017
# Licence:     <your licence>
#-------------------------------------------------------------------------------
from time import sleep
import webbrowser

import os

a=0

while True:

    webbrowser.open_new("http://foolando.blogspot.com")
    sleep(10)
    os.system("killall 'Google Chrome'")
    a=a+0
    sleep(10)